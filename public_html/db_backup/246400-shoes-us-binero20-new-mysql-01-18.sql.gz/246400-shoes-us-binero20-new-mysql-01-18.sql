
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `categoryID` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`categoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Herr'),(2,'Dam'),(3,'Rea');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categorydetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorydetails` (
  `productID` int(10) NOT NULL,
  `categoryID` int(10) NOT NULL,
  PRIMARY KEY (`productID`,`categoryID`),
  KEY `categoryID` (`categoryID`),
  KEY `productID` (`productID`),
  CONSTRAINT `categorydetails_ibfk_1` FOREIGN KEY (`categoryID`) REFERENCES `category` (`categoryID`),
  CONSTRAINT `categorydetails_ibfk_2` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categorydetails` WRITE;
/*!40000 ALTER TABLE `categorydetails` DISABLE KEYS */;
INSERT INTO `categorydetails` VALUES (1,1),(2,2),(3,2),(4,2),(5,2),(6,2),(7,1),(8,1),(9,1),(10,1),(11,2),(12,1),(13,1),(14,2);
/*!40000 ALTER TABLE `categorydetails` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `productID` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `price` int(6) NOT NULL,
  `inStock` int(3) NOT NULL,
  `discount` float NOT NULL,
  `img_path` text NOT NULL,
  PRIMARY KEY (`productID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Brun Läderkänga',499,10,50,'id_1.jpg'),(2,'Grå Pumps',299,10,0,'id_2.jpg'),(3,'Michael Kors Boots',1399,10,0,'id_3.jpg'),(4,'Superga Sneakers',799,10,0,'id_4.jpg'),(5,'Svarta Pumps',299,10,0,'id_5.jpg'),(6,'Stilettklackar',499,10,0,'id_6.jpg'),(7,'Brun Skinnsko',999,10,100,'id_7.jpg'),(8,'Röd Sneaker',399,10,0,'id_8.jpg'),(9,'Svart Sandal',199,10,0,'id_9.jpg'),(10,'Blå Sneaker',399,10,0,'id_10.jpg'),(11,'Mintgrön Sandal',399,10,0,'id_11.jpg'),(12,'Ljusbrun Finsko',799,10,0,'id_12.jpg'),(13,'Nike Sneaker',799,10,80,'id_13.jpg'),(14,'Fila Sneakers',899,10,0,'id_14.jpg');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase` (
  `purchaseID` int(10) NOT NULL AUTO_INCREMENT,
  `userID` int(10) NOT NULL,
  `shipperID` int(10) NOT NULL,
  `date` date NOT NULL,
  `sum` float NOT NULL,
  PRIMARY KEY (`purchaseID`),
  KEY `userID` (`userID`),
  KEY `shipperID` (`shipperID`),
  CONSTRAINT `purchase_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`),
  CONSTRAINT `purchase_ibfk_2` FOREIGN KEY (`shipperID`) REFERENCES `shipper` (`shipperID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase` WRITE;
/*!40000 ALTER TABLE `purchase` DISABLE KEYS */;
INSERT INTO `purchase` VALUES (1,2,1,'2020-02-12',499);
/*!40000 ALTER TABLE `purchase` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchasedetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchasedetails` (
  `purchaseID` int(10) NOT NULL,
  `productID` int(10) NOT NULL,
  `quantity` int(4) NOT NULL,
  `sum` float NOT NULL,
  PRIMARY KEY (`purchaseID`,`productID`),
  KEY `purchaseID` (`purchaseID`),
  KEY `productID` (`productID`),
  CONSTRAINT `purchasedetails_ibfk_1` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`),
  CONSTRAINT `purchasedetails_ibfk_2` FOREIGN KEY (`purchaseID`) REFERENCES `purchase` (`purchaseID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchasedetails` WRITE;
/*!40000 ALTER TABLE `purchasedetails` DISABLE KEYS */;
INSERT INTO `purchasedetails` VALUES (1,1,1,499);
/*!40000 ALTER TABLE `purchasedetails` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `shipper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipper` (
  `shipperID` int(10) NOT NULL AUTO_INCREMENT,
  `info` text NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` int(10) NOT NULL,
  PRIMARY KEY (`shipperID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `shipper` WRITE;
/*!40000 ALTER TABLE `shipper` DISABLE KEYS */;
INSERT INTO `shipper` VALUES (1,'Vi har dem snabbaste leveranserna i norden! 1-2 dagar.','GreenShipper',1234567890),(2,'Leveranstid 3-4','PostNord',8987546),(3,'ExpressLeverans - få din produkt hemma inom 24h','DHL',836583);
/*!40000 ALTER TABLE `shipper` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscription` (
  `subscriptionID` int(10) NOT NULL AUTO_INCREMENT,
  `userID` int(10) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `fName` varchar(30) NOT NULL,
  `lName` varchar(40) NOT NULL,
  PRIMARY KEY (`subscriptionID`),
  KEY `userID` (`userID`),
  CONSTRAINT `subscription_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `subscription` WRITE;
/*!40000 ALTER TABLE `subscription` DISABLE KEYS */;
INSERT INTO `subscription` VALUES (1,NULL,'lucas@hotmail.com','Lucas','Persson');
/*!40000 ALTER TABLE `subscription` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `userID` int(10) NOT NULL AUTO_INCREMENT,
  `fName` varchar(30) NOT NULL,
  `lName` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(10) NOT NULL,
  `password` varchar(50) NOT NULL,
  `isAdmin` tinyint(1) NOT NULL,
  `city` varchar(30) NOT NULL,
  `postalcode` int(5) NOT NULL,
  `country` varchar(30) NOT NULL,
  `street` varchar(60) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Frida','Baldvinsdottir','frida@hotmail.com',1234567890,'hej',0,'Göteborg',23244,'Sweden','Kalles gata 2'),(2,'test','testare','test@test.com',1234567890,'098f6bcd4621d373cade4e832627b4f6',0,'göteborg',43380,'Sweden','Kalles gata 2'),(3,'olle','olsson','o.o',1234567890,'098f6bcd4621d373cade4e832627b4f6',1,'Uddevalla',43380,'Sweden','Kalles gata 2');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

